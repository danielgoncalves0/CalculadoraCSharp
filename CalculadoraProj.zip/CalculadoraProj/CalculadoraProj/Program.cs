﻿using CalculadoraProj;
using System;

class Program
{
    static void Main(string[] args)
    {
        // Criamos o objeto da nossa classe Calculadora
        Calculadora calc = new Calculadora();
        bool continuar = true;

        // Ciclo while para manter o programa a correr
        while (continuar)
        {
            Console.Clear();
            Console.WriteLine("==============================");
            Console.WriteLine("   CALCULADORA COM CLASSES    ");
            Console.WriteLine("==============================");

            // Pedir o primeiro número
            Console.Write("Digite o primeiro número: ");
            double num1 = Convert.ToDouble(Console.ReadLine());

            // Pedir a operação
            Console.Write("Escolha a operação (+, -, *, /): ");
            string operacao = Console.ReadLine();

            // Pedir o segundo número
            Console.Write("Digite o segundo número: ");
            double num2 = Convert.ToDouble(Console.ReadLine());

            double resultado = 0;
            bool operacaoValida = true;

            // Estrutura switch para escolher o método correto da classe
            switch (operacao)
            {
                case "+":
                    resultado = calc.Somar(num1, num2);
                    break;
                case "-":
                    resultado = calc.Subtrair(num1, num2);
                    break;
                case "*":
                    resultado = calc.Multiplicar(num1, num2);
                    break;
                case "/":
                    resultado = calc.Dividir(num1, num2);
                    break;
                default:
                    Console.WriteLine("\n[Aviso] Operação inválida!");
                    operacaoValida = false;
                    break;
            }

            // Mostrar o resultado se a operação for válida
            if (operacaoValida)
            {
                Console.WriteLine($"\n> Resultado: {num1} {operacao} {num2} = {resultado}");
            }

            // Perguntar se quer continuar (com ReadLine normal, sem truques)
            Console.WriteLine("\n------------------------------");
            Console.Write("Queres fazer outra conta? (s/n): ");
            string resposta = Console.ReadLine();

            if (resposta != "s" && resposta != "S")
            {
                continuar = false;
                Console.WriteLine("\nA sair...");
            }
        }
    }
}