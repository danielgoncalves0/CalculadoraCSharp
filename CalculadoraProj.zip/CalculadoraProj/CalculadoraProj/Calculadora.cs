﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculadoraProj
{
    internal class Calculadora
    {
            // Método para somar dois números
            public double Somar(double a, double b)
            {
                return a + b;
            }

            // Método para subtrair dois números
            public double Subtrair(double a, double b)
            {
                return a - b;
            }

            // Método para multiplicar dois números
            public double Multiplicar(double a, double b)
            {
                return a * b;
            }

            // Método para dividir dois números com proteção contra divisão por zero
            public double Dividir(double a, double b)
            {
                if (b == 0)
                {
                    throw new DivideByZeroException("Não podes dividir por zero!");
                }
                return a / b;
            }
        }
    }


